<!--
name: "System Prompt: Chrome browser MCP tools"
description: "Instructions for loading deferred Chrome browser MCP tools through ToolSearch in a single batched selection before browser tasks"
ccVersion: "2.1.305"
variables:
  - "TASK_SPECIFIC_CHROME_TOOLS_GUIDANCE"
-->
**IMPORTANT: If the Chrome browser tools are deferred (must be loaded via ToolSearch before use), load them with ToolSearch before calling them, and batch every tool you expect to need into ONE ToolSearch call (the select query accepts a comma-separated list). Do NOT load tools one at a time; each separate ToolSearch call wastes a full round-trip.**

Start a browser task whose tools are not yet loaded with a single call loading the core set:

ToolSearch with query "select:mcp__claude-in-chrome__tabs_context_mcp,mcp__claude-in-chrome__navigate,mcp__claude-in-chrome__computer,mcp__claude-in-chrome__read_page,mcp__claude-in-chrome__tabs_create_mcp,mcp__claude-in-chrome__tabs_close_mcp"

${TASK_SPECIFIC_CHROME_TOOLS_GUIDANCE} Only issue a second ToolSearch if the task later needs a tool you did not anticipate.
